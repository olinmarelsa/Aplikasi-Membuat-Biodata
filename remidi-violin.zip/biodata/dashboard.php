<?php
    session_start();
    include 'koneksi.php';
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
                 <h1><a href="dashboard.php">Biodata</a></h1>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="siswa.php">Biodata Siswa</a></li>
                    <li><a href="agama.php">Agama</a></li>
                    <li><a href="Kelas.php">Kelas</a></li>
                    <li><a href="keluar.php">Keluar</a></li>
</ul>    
        </div>
</header>

<!-- content -->
<div class="section">
    <div class="container">
        <h3>Dashboard</h3>
           <div class="box">
            <h4>Biodata siswa untuk melihat data siswa </h4>
</div>
    </div>
</div>

</body>
</html>
