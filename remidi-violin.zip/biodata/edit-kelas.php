<?php
    session_start();
    include 'koneksi.php';
    $kelas = mysqli_query($conn,"SELECT * FROM biodata_kelas WHERE id = '".$_GET['id']."' ");
    $k =mysqli_fetch_object($kelas);
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
                 <h1><a href="dashboard.php">Biodata</a></h1>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="siswa.php">Biodata Siswa</a></li>
                    <li><a href="agama.php">Agama</a></li>
                    <li><a href="Kelas.php">Kelas</a></li>
                    <li><a href="keluar.php">Keluar</a></li>
</ul>    
        </div>
</header>
<!-- content -->
<div class="section">
    <div class="container">
        <h3>Tambah Data Kelas</h3>
        <div class="box">
            <form action="" method="POST" enctype="multipart/form-data">
                </select>
                    <input type="text" name="kelas" class="input-control" placeholder="Kelas" value="<?php echo $k->kelas?>"  required>
                    <input type="text" name="kompetensi" class="input-control" placeholder="Kompetensi" value="<?php echo $k->kompetensi?>" required>
                    <input type="number" name="tahun_pelajaran" class="input-control" placeholder="Tahun Pelajaran"  value="<?php echo $k->tahun_pelajaran?>" required>
                    <input type="text" name="keterangan" class="input-control" placeholder="Keterangan"  value="<?php echo $k->keterangan?>" required>
                    <input type="submit" name="submit" value="Submit" class="btn">
</form>
<?php 
            if(isset($_POST['submit'])) {
                $kelas             = $_POST['kelas'];
                $kompetensi        = $_POST['kompetensi'];
                $tahun_pelajaran   = $_POST['tahun_pelajaran'];
                $keterangan        = $_POST['keterangan'];
                $update = mysqli_query($conn, "UPDATE biodata_kelas SET 
                                        kelas           = '".$kelas."',
                                        kompetensi      = '".$kompetensi."',
                                        tahun_pelajaran = '".$tahun_pelajaran."',
                                        keterangan      = '".$keterangan."'
                                        WHERE id        = '".$k->id."' ");
                if($update){
            echo '<script>alert("Ubah data berhasil")</script>';
            echo '<script>window.location="kelas.php"</script>';
             }else{
            echo 'gagal'.mysqli_error($conn);
                                   }
                                }
?>
</div>
    </div>
</div>
</body>
</html>
