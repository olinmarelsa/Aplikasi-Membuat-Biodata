<?php
    session_start();
    include 'koneksi.php';
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
                 <h1><a href="dashboard.php">Biodata</a></h1>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="siswa.php">Biodata Siswa</a></li>
                    <li><a href="agama.php">Agama</a></li>
                    <li><a href="Kelas.php">Kelas</a></li>
                    <li><a href="keluar.php">Keluar</a></li>
</ul>    
        </div>
</header>
<!-- content -->
<div class="section">
    <div class="container">
        <h3>Tambah Data Siswa</h3>
        <div class="box">
            <form action="" method="POST" enctype="multipart/form-data">
                
                </select>
                    <input type="text" name="nama" class="input-control" placeholder="Nama" required>
                    <input type="text" name="tplahir" class="input-control" placeholder="Tempat Lahir" required>
                    <input type="date" name="tglahir" class="input-control" placeholder="Tanggal Lahir" required>
                    <input type="text" name="alamat" class="input-control" placeholder="Alamat" required>
                    <input type="text" name="hobi" class="input-control" placeholder="Hobi" required>
                    <input type="text" name="cita_cita" class="input-control" placeholder="Cita - Cita" required>
                    <input type="text" name="jm_saudara" class="input-control" placeholder="Jumlah Saudara" required>
                    <input type="text" name="idkelas" class="input-control" placeholder="Kelas" required>                   
                    <input type="text" name="idagama" class="input-control" placeholder="Agama" required>
                    <input type="submit" name="submit" value="Submit" class="btn">
</form>
<?php 
            if(isset($_POST['submit'])) {

                // menampung inputan dari form 
                $nama    = $_POST['nama'];
                $tplahir        = $_POST['tplahir'];
                $tglahir      = $_POST['tglahir'];
                $alamat   = $_POST['alamat'];
                $hobi      = $_POST['hobi'];
                $cita_cita      = $_POST['cita_cita'];
                $jm_saudara      = $_POST['jm_saudara'];
                $idkelas     = $_POST['idkelas'];
                $idagama      = $_POST['idagama'];
               

                    $insert = mysqli_query($conn, "INSERT INTO biodata_siswa VALUES (
                                null,
                                '".$nama."',
                                '".$tplahir."',
                                '".$tglahir."',
                                '".$alamat."',
                                '".$hobi."',
                                '".$cita_cita."',
                                '".$jm_saudara."',
                                '".$idkelas."',
                                '".$idagama."') ");
                    if($insert){
                        echo '<script>alert("Tambah data berhasil")</script>';
                        echo '<script>window.location="siswa.php"</script>';
             }else{
                        echo 'gagal'.mysqli_error($conn);
                    }

                }
                
                    
?>
</div>
    </div>
</div>
</body>
</html>
