<?php
//cek button    
    if ($_POST['Submit'] == "Submit") {
    $id    = $_POST['id'];
    $nama            = $_POST['nama'];
    $alamat        = $_POST['jurusan'];
    $tplahir          = $_POST['tplahir'];
    $hobi        = $_POST['hobi'];
    $cita        = $_POST['cita_cita'];
    $jmsaudara   = $_POST['jm_saudara'];

    //validasi data data kosong
    if (empty($_POST['id'])||empty($_POST['nama'])||empty($_POST['alamat'])||empty($_POST['tplahir'])||empty($_POST['hobi'])||empty($_POST['cita_cita'])||empty($_POST['jm_saudara'])) {
        ?>
            <script language="JavaScript">
                alert('Data Harap Dilengkapi!');
                document.location='biodata.php';
            </script>
        <?php
    }
    else {
    include "koneksi.php";
   '<script>window.location="biodata.php"</script>';
    }
}
?>