<h2>BIODATA</h2>

<table border="1" style="border-collapse:collapse">
<tr bgcolor="#eee">
    <th widht="50">No</th>
    <th widht="50">Nama</th>
    <th widht="50">Tempat Lahir</th>
    <th widht="50">Tanggal Lahir</th>
    <th widht="50">Alamat</th>
    <th widht="50">Hobi</th>
    <th widht="50">Cita-Cita</th>
    <th widht="50">Jumlah Saudara</th>
    <th widht="50">Aksi</th>
   
</tr>
<?php
include 'koneksi.php'; 
$no=1;
$biodata = mysqli_query($koneksi,"SELECT * FROM biodata_siswa ORDER BY id DESC");
while ($tampil = mysqli_fetch_array($biodata)) {
  ?>
    <tr>
    <td><?php echo $no++ ?></td>
    <td><?php echo $tampil['nama'] ?></td>
    <td><?php echo $tampil['tplahir'] ?></td>
    <td><?php echo $tampil['tglahir'] ?></td>
    <td><?php echo $tampil['alamat'] ?></td>
    <td><?php echo $tampil['hobi'] ?></td>
    <td><?php echo $tampil['cita_cita'] ?></td>
    <td><?php echo $tampil['jm_saudara'] ?></td>
    <td>
      <a href="siswa.php?id-<?php echo $tampil['id'] ?>">Edit</a> || <a href="proses-hapus.php?idb-<?php echo $tampil['id'] ?>" onclick
      ="return confirm('Yakin ingin hapus?')">Hapus</a>
    </td>
  </tr>
<?php } ?>  

