<?php
$koneksi = mysqli_connect("localhost","root","","ujian") or die (mysqli_connect_error());
?>
