<?php 
 include 'koneksi.php'; 
if (isset($_GET['del'])) {
    $delete =mysqli_query($koneksi,"DELETE FROM biodata_siswa WHERE id ='".$_GET['del']."' ");
    echo '<script>window.location="biodata.php"</script>';
}
?>