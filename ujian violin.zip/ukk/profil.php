<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata Siswa</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksan&display=swap" rel="stylesheet">
    </head>
    <body>
     
     </header>

     <div class="section">
        <div class="container">
            <h3>Profil Admin</h3>
            <div class="box">
                <form action="" method="POST">
                <input type="text" name="nama" placeholder= "Nama Lengkap" class="input-control" required>
                <input type="text" name="user" placeholder= "Username" class="input-control" required>
                <input type="text" name="pass" placeholder= "Password" class="input-control" required>
                <input type="submit" name="submit" value="Ubah Data Admin">
                </form>
        
    </body>
</html>