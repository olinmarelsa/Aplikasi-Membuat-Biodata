<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata Siswa</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksan&display=swap" rel="stylesheet">
    </head>
    <body>
     <!--header-->
     <header>
        <div class="container">
        <h1><a href="dashboard.php">BIODATA SISWA</a></h1>
        <ul>
            <li><a href="biodata.php">Biodata Siswa</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="">Biodata Agama</a></li>
            <li><a href="keluar.php">Keluar</a></li>
        </ul>
     </header>
        
    </body>
</html>