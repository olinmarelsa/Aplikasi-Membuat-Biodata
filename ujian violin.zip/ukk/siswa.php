<html>
<head>
    <title>Biodata Siswa</title>
    <style type="text/css" media="screen">
        table {font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;}
        input {font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;height: 20px;}
    </style>
</head>
<body>
<div style="border:0; padding:10px; width:760px; height:auto;">
<form action="action-input-data.php" method="POST">
    <table width="760" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr height="46">
                <td width="10%"> </td>
                <td width="25%"> </td>
                <td width="65%"><font color="pink" size="2">Form Input Biodata</font></td>
        </tr>
        <tr height="46">
            <td> </td>
            <td>No siswa</td>
            <td><input type="text" name="id" size="35" maxlength="6" /></td>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Nama</td>
            <td><input type="text" name="nama" size="50" maxlength="30" /></td>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Jurusan</td>
            <td><select name="jurusan">
                    <option value="-">- Pilih Jurusan -
                    <option value="Teknik Komputer dan jaringan">Teknik Komputer dan jaringan
                    <option value="RPL">RPL
                    <option value="TKR">TKR
                    <option value="DKV">DKV
                    <option value="ANIMASI">ANIMASI
                </select></td>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Tempat Lahir</td>
            <td><input type="text" name="tplahir" size="50" maxlength="30" /></td>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Tanggal Lahir</td>
            <td><input type="text" name="tglahir" size="20" maxlength="12" /></td>
        </tr>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Alamat</td>
            <td><input type="text" name="alamat" size="50" maxlength="30" /></td>
        </tr>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Hobi</td>
            <td><input type="text" name="hobi" size="50" maxlength="30" /></td>
        </tr>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Cita-Cita</td>
            <td><input type="text" name="cita_cita" size="50" maxlength="30" /></td>
        </tr>
        </tr>
        <tr height="46">
            <td> </td>
            <td>Jumlah Saudara</td>
            <td><input type="text" name="jm_saudara" size="50" maxlength="30" /></td>
        </tr>
        </tr>
        <tr height="46">
            <td> </td>
            <td> </td>
            <td><input type="submit" name="Submit" value="Submit">   
                <input type="reset" name="reset" value="Cancel"></td>
        </tr>
    </table>
</form>
</div>
</body>
</html>