<?php
    session_start();
    include 'db.php';
    if($_SESSION['status_login'] != true){
        echo '<script>window.location="login.php"</script>';
    }

    $siswa = mysqli_query($conn, "SELECT * FROM biodata_siswa WHERE id = '".$_GET['id']."' ");
    if(mysqli_num_rows($siswa)==0){
        echo '<script>window.location="biodata-siswa.php"</script>';
    }
    $p = mysqli_fetch_object($siswa);
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata Siswa</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
            <h1><a href="dashboard.php">Vimina Hijab</a></h1>
                 <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="biodata-siswa.php">Biodata Siswa</a></li>
                    <li><a href="biodata-kelas.php">Biodata Kelas</a></li>
                    <li><a href="biodata-agama.php">Biodata Agama</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="logout.php">Keluar</a></li>
</ul>    
        </div>
</header>

<!-- content -->
<div class="section">
    <div class="container">
        <h3>Edit Data Siswa</h3>
           <div class="box">
            <form action="" method="POST" enctype="multipart/form-data">
                <?php
                    $siswa = mysqli_query($conn, "SELECT * FROM biodata_siswa ORDER BY id DESC");
                    while($r = mysqli_fetch_array($siswa)){
                ?>
                 <option value="<?php echo $r['id'] ?>"<?php echo ($r['id'] == $p->id)? 'selected':''; 
                 ?>><?php echo $r ['nama'] ?></option>
                <?php } ?>
                </select>

                    <input type="text" name="nama" class="input-control" placeholder="Nama" value="<?php echo $p->nama
                    ?>" required>
                    <input type="text" name="tplahir" class="input-control" placeholder="Tempat Lahir" value="<?php echo $p->tplahir
                    ?>" required>
                     <input type="date" name="tg;ahir" class="input-control" placeholder="Tanggal Lahir" value="<?php echo $p->tglahir
                    ?>" required>
                     <input type="text" name="alamat" class="input-control" placeholder="Alamat" value="<?php echo $p->alamat
                    ?>" required>
                     <input type="text" name="hobi" class="input-control" placeholder="Hobi" value="<?php echo $p->hobi
                    ?>" required>
                     <input type="text" name="cita_cita" class="input-control" placeholder="Cita-Cita" value="<?php echo $p->cita_cita
                    ?>" required>
                     <input type="text" name="jm_saudara" class="input-control" placeholder="Jumlah Saudara" value="<?php echo $p->jm_saudara
                    ?>" required>
                    <input type="submit" name="submit" value="Submit" class="btn">
</form>
<?php 
            if(isset($_POST['submit'])) {

                //data inputan dari form
               
                $nama        = $_POST['nama'];
                $tplahir      = $_POST['tplahir'];
                $tglahir   = $_GET ['tglahir'];
                $alamat      = $_POST['alamat'];
                $hobi        = $_POST['hobi'];
                $cita        = $_POST['cita_cita'];
                $jm_saudara        = $_POST['jm_saudara'];
        
                //query update data produk
                $update = mysqli_query($conn, "UPDATE biodata_siswa SET
                                        nama= '".$nama."', 
                                        tplahir= '".$tplahir."',
                                        tglahir= '".$tglahir."',
                                        alamat= '".$alamat."',
                                        hobi= '".$hobi."'
                                        cita_cita= '".$cita."'
                                        jm_saudara= '".$jm_saudara."'
                                        WHERE id_produk ='".$p->id."' ");
             if($update){
             echo '<script>alert("Tambah data berhasil")</script>';
             echo '<script>window.location="biodata-siswa.php"</script>';
                    
           }else{
                    
             echo 'gagal'.mysqli_error($conn);
           }
                    }
                
?>
</div>
    </div>
</div>

</body>
</html>
