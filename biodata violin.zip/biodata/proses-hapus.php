<?php

include 'db.php';
if(isset($_GET['ids'])) {
    $delete = mysqli_query($conn, "DELETE FROM biodata_siswa WHERE id = '".$_GET['ids']."' ");
    echo '<script>window.location="biodata-siswa.php"</script>';
}
?>
