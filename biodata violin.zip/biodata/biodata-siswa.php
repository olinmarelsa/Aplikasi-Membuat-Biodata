<?php
    session_start();
    include 'db.php';
    if($_SESSION['status_login'] != true){
        echo '<script>window.location="login.php"</script>';
    }
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata Siswa</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
                 <h1><a href="dashboard.php">Biodata Siswa SMKN 11 Malang</a></h1>
                 <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="biodata-siswa.php">Biodata Siswa</a></li>
                    <li><a href="biodata-kelas.php">Biodata Kelas</a></li>
                    <li><a href="biodata-agama.php">Biodata Agama</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="logout.php">Keluar</a></li>
</ul>    
        </div>
</header>

<!-- content -->
<div class="section">
    <div class="container">
        <h3>Biodata Siswa</h3>
           <div class="box">
            <p><a href="tambah-siswa.php">Tambah Data Siswa</a></p>
            <table border ="1" cellspacing="0" class="table">
                <thead>
                    <tr>
                        <th width="60px" >No</th>
                        <th>Nama</th>
                        <th>Tempat Lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>Alamat</th>
                        <th>Hobi</th>
                        <th>Cita-Cita</th>
                        <th>Jumlah Saudara</th>
                        <th width="150px">Aksi</th>
</tr>
                </thead>
                <tbody>
                    <?php
                    $no =1;
                    $siswa = mysqli_query($conn," SELECT * FROM biodata_siswa ORDER BY id DESC");
                    if(mysqli_num_rows($siswa) > 0){
            
                    while($row = mysqli_fetch_array($siswa)){
                    ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $row['nama']?></td>
                        <td><?php echo $row['tplahir']?></td>
                        <td><?php echo $row['tglahir']?></td>
                        <td><?php echo $row['alamat']?></td>
                        <td><?php echo $row['hobi']?></td>
                        <td><?php echo $row['cita_cita']?></td>
                        <td><?php echo $row['jm_saudara']?></td>
                        <td>
                            <a href="edit-siswa.php?id=<?php echo $row['id'] ?>">Edit</a> || <a href="
                            proses-hapus.php?ids=<?php echo $row['id'] ?>" onclick="return confirm('Yakin ingin hapus ?'
                            )">Hapus</a>
</td>
</tr>
                        <?php }}else{ ?>
                            <tr>
                                <td colspan="9">Tidak ada data</td>

                            </tr>

                            <?php } ?>
</tbody>
</table>
           
</div>
    </div>
</div>

</body>
</html>